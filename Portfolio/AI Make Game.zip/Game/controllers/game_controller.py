from config import STATUS, TOTAL_MONTHS
from services import CharacterService, EndingService
from views import GameViews
from .schedule_controller import ScheduleController


class GameController:
  def __init__(self, store):
    self.store = store
    self.views = GameViews()
    self.characterService = CharacterService(store)
    self.endingService = EndingService()
    self.scheduleController = ScheduleController(store)

  def newGame(self):
    while True:
      name = self.views.promptName()
      if not name:
        self.views.showError('이름을 입력해 주세요.')
        continue

      result = self.characterService.createCharacter(name)
      if result.get('status') == STATUS['ERROR']:
        self.views.showError('캐릭터 생성에 실패했습니다.')
        return None

      characters = result.get('data') or []
      character = characters[-1] if characters else None
      if character is None:
        self.views.showError('캐릭터 생성에 실패했습니다.')
        return None

      self.views.showCharacterCreated(character)
      return self._play(character)

  def continueGame(self):
    while True:
      listResult = self.characterService.listCharacters()
      if listResult.get('status') == STATUS['ERROR']:
        self.views.showError('세이브를 불러오지 못했습니다.')
        return None

      characters = listResult.get('data') or []
      self.views.showSaveList(characters)

      if not characters:
        choice = self.views.promptChoice('엔터로 돌아가기 >> ')
        return None

      choice = self.views.promptChoice('세이브 선택 >> ')
      if choice == '0' or choice == '':
        return None

      if choice.lower().startswith('d'):
        rawId = choice[1:].strip()
        if not rawId.isdigit():
          self.views.showInvalidChoice()
          continue
        self.deleteSave(int(rawId))
        continue

      if not choice.isdigit():
        self.views.showInvalidChoice()
        continue

      characterId = int(choice)
      findResult = self.characterService.getCharacter(characterId)
      if findResult.get('status') == STATUS['ERROR']:
        self.views.showError('해당 세이브를 찾을 수 없습니다.')
        continue

      character = findResult.get('data')
      if character.get('ending') or int(character.get('turn', 0)) >= TOTAL_MONTHS:
        endingResult = self.endingService.resolve(character)
        if endingResult.get('status') == STATUS['SUCCESS']:
          self.views.showEnding(character, endingResult.get('data'))
        else:
          self.views.showMessage('이미 졸업한 캐릭터입니다.')
        continue

      return self._play(character)

  def deleteSave(self, characterId):
    result = self.characterService.deleteCharacter(characterId)
    if result.get('status') == STATUS['ERROR']:
      self.views.showError('세이브 삭제에 실패했습니다.')
      return False

    self.views.showMessage(f'세이브 [{characterId}]를 삭제했습니다.')
    return True

  def _play(self, character):
    current = self.scheduleController.runTurnLoop(character)
    if int(current.get('turn', 0)) >= TOTAL_MONTHS and not current.get('ending'):
      return self.showEnding(current)
    return current

  def showEnding(self, character):
    endingResult = self.endingService.resolve(character)
    if endingResult.get('status') == STATUS['ERROR']:
      self.views.showError('엔딩을 판정하지 못했습니다.')
      return character

    ending = endingResult.get('data')
    saveResult = self.characterService.updateCharacter(
      character.get('id'),
      {'ending': ending.get('name')},
    )
    if saveResult.get('status') == STATUS['SUCCESS']:
      savedList = saveResult.get('data') or []
      character = next(
        (item for item in savedList if int(item.get('id')) == int(character.get('id'))),
        {**character, 'ending': ending.get('name')},
      )
    else:
      character = {**character, 'ending': ending.get('name')}

    self.views.showEnding(character, ending)
    return character
