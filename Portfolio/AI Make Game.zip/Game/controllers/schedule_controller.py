from copy import deepcopy
from time import sleep

from config import (
  STATUS,
  CODE,
  TOTAL_MONTHS,
  MONTHLY_ACTIONS,
  DAYS_PER_ACTION,
  DAY_PAUSE_SECONDS,
  DAY_PAUSE_SPECIAL_SECONDS,
  OUTCOME_CRITICAL_SUCCESS,
  OUTCOME_SUCCESS,
  OUTCOME_FAILURE,
  OUTCOME_CRITICAL_FAILURE,
)
from services import ActionService, CharacterService
from views import GameViews


class ScheduleController:
  def __init__(self, store):
    self.store = store
    self.views = GameViews()
    self.actionService = ActionService(store)
    self.characterService = CharacterService(store)

  def runTurnLoop(self, character):
    current = character

    while int(current.get('turn', 0)) < TOTAL_MONTHS:
      self.views.showStatus(current)
      plan = self._promptValidPlan()
      if plan is None:
        self.views.showMessage('메인 메뉴로 돌아갑니다. 진행 상황은 저장됩니다.')
        return current

      monthResult = self._runMonth(current, plan)
      if monthResult is None:
        self.views.showError('계획을 적용하지 못했습니다. 다시 입력해 주세요.')
        continue

      if monthResult.get('status') == STATUS['ERROR']:
        if monthResult.get('code') == CODE['GAME_FINISHED']:
          break
        self.views.showError('계획을 적용하지 못했습니다. 다시 입력해 주세요.')
        continue

      payload = monthResult.get('data') or {}
      updated = payload.get('character')
      saveResult = self.characterService.updateCharacter(
        updated.get('id'),
        {
          'turn': updated.get('turn'),
          'month': updated.get('month'),
          'stats': updated.get('stats'),
          'history': updated.get('history'),
          'action_counts': updated.get('action_counts'),
          'events_triggered': updated.get('events_triggered'),
        },
      )
      if saveResult.get('status') == STATUS['ERROR']:
        self.views.showError('저장에 실패했습니다.')
        return current

      savedList = saveResult.get('data') or []
      current = next(
        (item for item in savedList if int(item.get('id')) == int(updated.get('id'))),
        updated,
      )
      self.views.showMonthResult(payload)

    return current

  def _runMonth(self, character, plan):
    validateResult = self.actionService.validatePlan(character, plan)
    if validateResult.get('status') == STATUS['ERROR']:
      return validateResult

    validated = validateResult.get('data') or {}
    actionIds = validated.get('action_ids') or []
    actionNames = validated.get('action_names') or []

    beforeStats = deepcopy(character.get('stats') or {})
    current = character
    monthDelta = {
      'money': 0,
      'intelligence': 0,
      'charm': 0,
      'stamina': 0,
      'stress': 0,
    }
    outcomeTotals = {
      OUTCOME_CRITICAL_SUCCESS: 0,
      OUTCOME_SUCCESS: 0,
      OUTCOME_FAILURE: 0,
      OUTCOME_CRITICAL_FAILURE: 0,
    }
    dayLogs = []
    day = 0

    self.views.showMonthStart(actionNames)

    for actionId in actionIds:
      for _repeat in range(DAYS_PER_ACTION):
        day += 1
        dayResult = self.actionService.applyDay(current, actionId, day)
        if dayResult.get('status') == STATUS['ERROR']:
          return dayResult

        payload = dayResult.get('data') or {}
        current = payload.get('character')
        dayLog = payload.get('day_log') or {}
        dayLogs.append(dayLog)
        outcomeTotals[dayLog.get('outcome')] = outcomeTotals.get(dayLog.get('outcome'), 0) + 1

        for statKey, change in (dayLog.get('delta') or {}).items():
          monthDelta[statKey] = monthDelta.get(statKey, 0) + change

        self.views.showDayResult(dayLog, current)
        pause = DAY_PAUSE_SPECIAL_SECONDS if dayLog.get('outcome') in (
          OUTCOME_CRITICAL_SUCCESS,
          OUTCOME_CRITICAL_FAILURE,
        ) else DAY_PAUSE_SECONDS
        sleep(pause)

    finishResult = self.actionService.finishMonth(current, actionNames)
    if finishResult.get('status') == STATUS['ERROR']:
      return finishResult

    updated = finishResult.get('data')
    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_SAVED'],
      'data': {
        'character': updated,
        'delta': monthDelta,
        'before_stats': beforeStats,
        'after_stats': updated.get('stats'),
        'action_names': actionNames,
        'outcome_totals': outcomeTotals,
        'day_logs': dayLogs,
      },
    }

  def _promptValidPlan(self):
    self.views.showActionMenu()
    actionIds = []

    while len(actionIds) < MONTHLY_ACTIONS:
      step = len(actionIds) + 1
      raw = self.views.promptPlanChoice(step)
      if raw.lower() in ('q', 'quit', 'exit'):
        return None

      if not raw.isdigit() or self.actionService.getAction(raw)['status'] != STATUS['SUCCESS']:
        self.views.showError('1~8 범위의 행동 번호만 입력해 주세요.')
        continue

      actionIds.append(int(raw))

    return actionIds
