import os
import sys

from managers import DataManager
from controllers import GameController
from views import GameViews

basePath = os.path.dirname(__file__)

store = DataManager(basePath=basePath)
gameController = GameController(store)
views = GameViews()


def main():
  while True:
    views.showIntro()
    choice = views.promptChoice('선택 (1-3) >> ')

    if choice == '1':
      gameController.newGame()
    elif choice == '2':
      gameController.continueGame()
    elif choice == '3':
      views.showGoodbye()
      sys.exit(0)
    else:
      views.showInvalidChoice()


if __name__ == '__main__':
  main()
