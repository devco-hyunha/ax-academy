from copy import deepcopy
from random import random

from config import (
  ACTIONS,
  EVENTS,
  STATUS,
  CODE,
  STAT_MIN,
  STAT_MAX,
  MONTHLY_ACTIONS,
  TOTAL_MONTHS,
  OUTCOME_CRITICAL_SUCCESS,
  OUTCOME_SUCCESS,
  OUTCOME_FAILURE,
  OUTCOME_CRITICAL_FAILURE,
  OUTCOME_MULTIPLIERS,
  CRITICAL_FAILURE_STRESS_BONUS,
)


class ActionService:
  def __init__(self, store):
    self.store = store

  def _findAction(self, actionId):
    try:
      parsedId = int(actionId)
    except (TypeError, ValueError):
      return None

    for action in ACTIONS:
      if action['id'] == parsedId:
        return action
    return None

  def getAction(self, actionId):
    action = self._findAction(actionId)
    if action is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['INVALID_ACTION'],
        'data': None,
      }
    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_FETCHED'],
      'data': action,
    }

  def listActions(self):
    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_FETCHED'],
      'data': ACTIONS,
    }

  def validatePlan(self, character, actionIds):
    if character is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['DATA_NOT_FOUND'],
        'data': None,
      }

    if int(character.get('turn', 0)) >= TOTAL_MONTHS:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['GAME_FINISHED'],
        'data': character,
      }

    if not isinstance(actionIds, list) or len(actionIds) != MONTHLY_ACTIONS:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['INVALID_PLAN'],
        'data': None,
      }

    parsedIds = []
    actionNames = []
    for actionId in actionIds:
      try:
        parsedId = int(actionId)
      except (TypeError, ValueError):
        return {
          'status': STATUS['ERROR'],
          'code': CODE['INVALID_ACTION'],
          'data': None,
        }

      action = self._findAction(parsedId)
      if action is None:
        return {
          'status': STATUS['ERROR'],
          'code': CODE['INVALID_ACTION'],
          'data': None,
        }
      parsedIds.append(parsedId)
      actionNames.append(action['name'])

    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_VALID'],
      'data': {
        'action_ids': parsedIds,
        'action_names': actionNames,
      },
    }

  def applyDay(self, character, actionId, day):
    if character is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['DATA_NOT_FOUND'],
        'data': None,
      }

    action = self._findAction(actionId)
    if action is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['INVALID_ACTION'],
        'data': None,
      }

    currentStats = deepcopy(character.get('stats') or {})
    actionCounts = {
      str(key): int(value)
      for key, value in (character.get('action_counts') or {}).items()
    }
    countKey = str(action['id'])
    practiceCount = actionCounts.get(countKey, 0)
    outcome = self._rollOutcome(practiceCount)
    dayDelta = self._applyWeights(action['weights'], outcome)

    for statKey, change in dayDelta.items():
      currentStats[statKey] = self._clampStat(
        statKey,
        int(currentStats.get(statKey, 0)) + change,
      )

    actionCounts[countKey] = practiceCount + 1
    updated = {
      **character,
      'stats': currentStats,
      'action_counts': actionCounts,
    }
    dayLog = {
      'day': day,
      'action_id': action['id'],
      'action_name': action['name'],
      'outcome': outcome,
      'delta': dayDelta,
      'practice_count': practiceCount,
    }

    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_SAVED'],
      'data': {
        'character': updated,
        'day_log': dayLog,
      },
    }

  def finishMonth(self, character, actionNames):
    if character is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['DATA_NOT_FOUND'],
        'data': None,
      }

    nextTurn = int(character.get('turn', 0)) + 1
    nextMonth = min(12, nextTurn + 1)
    updated = {
      **character,
      'turn': nextTurn,
      'month': nextMonth,
      'history': list(character.get('history') or []) + list(actionNames or []),
    }
    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_SAVED'],
      'data': updated,
    }

  def _rollOutcome(self, practiceCount):
    chances = self._outcomeChances(practiceCount)
    roll = random() * sum(chances.values())
    cumulative = 0.0
    for outcome, weight in chances.items():
      cumulative += weight
      if roll <= cumulative:
        return outcome
    return OUTCOME_SUCCESS

  def _outcomeChances(self, practiceCount):
    count = min(max(int(practiceCount), 0), 40)
    return {
      OUTCOME_CRITICAL_SUCCESS: 5 + count * 0.35,
      OUTCOME_SUCCESS: 45 + count * 0.55,
      OUTCOME_FAILURE: max(5.0, 40 - count * 0.55),
      OUTCOME_CRITICAL_FAILURE: max(2.0, 10 - count * 0.35),
    }

  def _applyWeights(self, weights, outcome):
    multiplier = OUTCOME_MULTIPLIERS[outcome]
    dayDelta = {
      'money': 0,
      'intelligence': 0,
      'charm': 0,
      'stamina': 0,
      'stress': 0,
    }

    for statKey, weight in weights.items():
      dayDelta[statKey] = int(round(weight * multiplier))

    if outcome == OUTCOME_CRITICAL_FAILURE:
      dayDelta['stress'] += CRITICAL_FAILURE_STRESS_BONUS

    return dayDelta

  def _clampStat(self, statKey, value):
    if statKey == 'money':
      return max(0, int(value))
    return max(STAT_MIN, min(STAT_MAX, int(value)))

  # --- 이벤트 mock (추후 schedule 루프에 연결) ---

  def findTriggeredEvent(self, character):
    if character is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['DATA_NOT_FOUND'],
        'data': None,
      }

    stats = character.get('stats') or {}
    triggered = character.get('events_triggered') or []

    for event in EVENTS.values():
      if event['id'] in triggered:
        continue
      if self._matchesEventTrigger(stats, event.get('trigger') or {}):
        return {
          'status': STATUS['SUCCESS'],
          'code': CODE['DATA_FETCHED'],
          'data': event,
        }

    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_FETCHED'],
      'data': None,
    }

  def applyEvent(self, character, eventId):
    event = EVENTS.get(eventId)
    if event is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['DATA_NOT_FOUND'],
        'data': None,
      }

    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_FETCHED'],
      'data': {
        'event': event,
        'days_lost': int(event.get('days_lost', 0)),
        'effects': event.get('effects') or {},
        'applied': False,
      },
    }

  def _matchesEventTrigger(self, stats, trigger):
    statKey = trigger.get('stat')
    if not statKey:
      return False

    current = int(stats.get(statKey, 0))
    value = int(trigger.get('value', 0))
    op = trigger.get('op', 'gte')

    if op == 'gte':
      return current >= value
    if op == 'lte':
      return current <= value
    if op == 'eq':
      return current == value
    return False
