from config import STATUS, CODE


class CharacterService:
  def __init__(self, store):
    self.store = store

  def listCharacters(self):
    return self.store.findAll('character')

  def getCharacter(self, characterId):
    return self.store.findBy('character', 'id', int(characterId))

  def createCharacter(self, name):
    cleanedName = (name or '').strip()
    if not cleanedName:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['MISSING_REQUIRED_DATA'],
        'data': None,
      }

    return self.store.create('character', {'name': cleanedName})

  def updateCharacter(self, characterId, fields):
    return self.store.update('character', int(characterId), fields)

  def deleteCharacter(self, characterId):
    return self.store.delete('character', int(characterId))
