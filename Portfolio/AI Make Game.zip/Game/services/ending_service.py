from config import ENDINGS, STATUS, CODE


class EndingService:
  def resolve(self, character):
    if character is None:
      return {
        'status': STATUS['ERROR'],
        'code': CODE['DATA_NOT_FOUND'],
        'data': None,
      }

    stats = character.get('stats') or {}
    money = int(stats.get('money', 0))
    intelligence = int(stats.get('intelligence', 0))
    charm = int(stats.get('charm', 0))
    stamina = int(stats.get('stamina', 0))
    stress = int(stats.get('stress', 0))

    endingId = self._pickEndingId(
      money=money,
      intelligence=intelligence,
      charm=charm,
      stamina=stamina,
      stress=stress,
    )
    ending = ENDINGS[endingId]

    return {
      'status': STATUS['SUCCESS'],
      'code': CODE['DATA_FETCHED'],
      'data': ending,
    }

  def _pickEndingId(self, money, intelligence, charm, stamina, stress):
    if intelligence >= 75 and charm >= 70 and stress <= 50:
      return 'large_company'
    if money >= 75 and intelligence >= 70:
      return 'startup'
    if intelligence >= 80 and money >= 55:
      return 'abroad'
    if charm >= 80:
      return 'youtuber'
    if stamina >= 75 and intelligence <= 45 and money <= 45:
      return 'labor'
    if intelligence >= 50:
      return 'sme'
    return 'unemployed'
