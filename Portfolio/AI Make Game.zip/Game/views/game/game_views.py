from utils import padByDisplayWidth
from config import (
  ACTIONS,
  STAT_LABELS,
  TOTAL_MONTHS,
  MONTHLY_ACTIONS,
  DAYS_PER_ACTION,
  OUTCOME_LABELS,
  OUTCOME_CRITICAL_SUCCESS,
  OUTCOME_SUCCESS,
  OUTCOME_FAILURE,
  OUTCOME_CRITICAL_FAILURE,
)
from .system_views import SystemViews


class GameViews(SystemViews):
  def showIntro(self):
    print(f"\n{'=' * 50}")
    print()
    print(padByDisplayWidth('대학생메이커', 50, align='center'))
    print()
    print(f"{'=' * 50}")
    print('  [1] 새로하기')
    print('  [2] 이어하기')
    print('  [3] 종료')
    print('=' * 50)

  def showCharacterCreated(self, character):
    print()
    print('-' * 50)
    print(padByDisplayWidth(f"{character.get('name')} 캐릭터가 생성되었습니다.", 50, align='center'))
    print('-' * 50)
    print()

  def showSaveList(self, characters):
    print()
    print('-' * 50)
    print(padByDisplayWidth('세이브 목록', 50, align='center'))
    print('-' * 50)
    if not characters:
      print('  저장된 캐릭터가 없습니다.')
      print('-' * 50)
      print()
      return

    for character in characters:
      ending = character.get('ending')
      ending_text = f" / 엔딩: {ending}" if ending else ''
      print(
        f"  [{character.get('id')}] {character.get('name')} "
        f"- {character.get('month')}월 "
        f"(턴 {character.get('turn')}/{TOTAL_MONTHS}){ending_text}"
      )
    print('-' * 50)
    print('  번호 입력: 불러오기')
    print('  d번호 입력: 삭제 (예: d1)')
    print('  0: 뒤로가기')
    print('-' * 50)
    print()

  def showStatus(self, character):
    stats = character.get('stats') or {}
    print()
    print('=' * 50)
    print(padByDisplayWidth(
      f"{character.get('name')} | {character.get('month')}월 | "
      f"턴 {character.get('turn')}/{TOTAL_MONTHS}",
      50,
      align='center',
    ))
    print('=' * 50)
    for key, label in STAT_LABELS.items():
      value = stats.get(key, 0)
      bar = self._statBar(value)
      print(f'  {padByDisplayWidth(label, 10)} {bar} {value:3d}')
    print('=' * 50)
    print()

  def showActionMenu(self):
    print(f'  [한달 계획] 행동 {MONTHLY_ACTIONS}개를 순서대로 선택하세요.')
    print(f'  각 행동은 {DAYS_PER_ACTION}일씩, 총 {MONTHLY_ACTIONS * DAYS_PER_ACTION}일로 진행됩니다.')
    print('  q: 메인 메뉴로 돌아가기')
    print('-' * 50)
    for action in ACTIONS:
      print(f"  [{action['id']}] {action['name']}")
    print('-' * 50)

  def promptPlanChoice(self, step):
    return input(f' {step}/{MONTHLY_ACTIONS}번째 행동 번호 >> ').strip()

  def showMonthStart(self, actionNames):
    print()
    print('-' * 50)
    print(padByDisplayWidth('한달 진행 시작', 50, align='center'))
    print('-' * 50)
    print(f"  계획: {', '.join(actionNames)}")
    print(f'  (각 {DAYS_PER_ACTION}일 × {MONTHLY_ACTIONS}행동 = {MONTHLY_ACTIONS * DAYS_PER_ACTION}일)')
    print('-' * 50)
    print()

  def showDayResult(self, dayLog, character):
    outcome = dayLog.get('outcome')
    outcomeLabel = OUTCOME_LABELS.get(outcome, outcome)
    delta = dayLog.get('delta') or {}
    changes = []
    for key, label in STAT_LABELS.items():
      change = int(delta.get(key, 0))
      if change == 0:
        continue
      sign = '+' if change > 0 else ''
      changes.append(f'{label}{sign}{change}')

    changeText = ', '.join(changes) if changes else '변화 없음'
    print(
      f"  {dayLog.get('day'):2d}일 | {dayLog.get('action_name')} | "
      f"{outcomeLabel} | {changeText}"
    )

    stats = character.get('stats') or {}
    if outcome in (OUTCOME_CRITICAL_SUCCESS, OUTCOME_CRITICAL_FAILURE):
      print(
        f"         → 현재 스탯 "
        f"재력{stats.get('money', 0)} "
        f"지능{stats.get('intelligence', 0)} "
        f"매력{stats.get('charm', 0)} "
        f"체력{stats.get('stamina', 0)} "
        f"스트레스{stats.get('stress', 0)}"
      )

  def showMonthResult(self, result):
    delta = result.get('delta') or {}
    action_names = result.get('action_names') or []
    outcome_totals = result.get('outcome_totals') or {}

    print()
    print('-' * 50)
    print(padByDisplayWidth('한달 결과 요약', 50, align='center'))
    print('-' * 50)
    print(f"  계획: {', '.join(action_names)}")
    print()
    print('  [주사위 판정]')
    for outcome_key in (
      OUTCOME_CRITICAL_SUCCESS,
      OUTCOME_SUCCESS,
      OUTCOME_FAILURE,
      OUTCOME_CRITICAL_FAILURE,
    ):
      label = OUTCOME_LABELS[outcome_key]
      count = int(outcome_totals.get(outcome_key, 0))
      print(f'  {padByDisplayWidth(label, 8)} {count}회')
    print()

    for key, label in STAT_LABELS.items():
      change = delta.get(key, 0)
      sign = '+' if change > 0 else ''
      print(f'  {padByDisplayWidth(label, 10)} {sign}{change}')
    print('-' * 50)
    print()

  def showEnding(self, character, ending):
    print()
    print('=' * 50)
    print(padByDisplayWidth('졸업의 계절', 50, align='center'))
    print('=' * 50)
    self.showStatus(character)
    print()
    print(padByDisplayWidth(f"엔딩: {ending.get('name')}", 50, align='center'))
    print()
    print(ending.get('message', ''))
    print()
    print('=' * 50)
    print()

  def _statBar(self, value, length=20):
    filled = max(0, min(length, int(round((int(value) / 100) * length))))
    return '[' + ('#' * filled) + ('.' * (length - filled)) + ']'
