class SystemViews:
  def promptChoice(self, message='선택 >> '):
    return input(f' {message}').strip()

  def promptName(self):
    return input(' 캐릭터 이름 >> ').strip()

  def showInvalidChoice(self):
    print()
    print('올바른 번호를 입력해 주세요.')
    print()

  def showMessage(self, message):
    print()
    print(message)
    print()

  def showError(self, message):
    print()
    print(f'[오류] {message}')
    print()

  def showGoodbye(self):
    print()
    print('게임을 종료합니다')
    print()
